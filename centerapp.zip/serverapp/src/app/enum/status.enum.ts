export enum Status {
    ALL = 'ALL', SERVER_UP = 'SERVER_UP', SERVER_DOWN = 'SERVER_DOWN'
}